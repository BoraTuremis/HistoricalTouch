package com.example.a20190305006;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class QuizActivity extends AppCompatActivity {

    private TextView tvQuestion, tvScore, tvQuestionNo;
    private RadioGroup radioGroup;
    private RadioButton rb1, rb2, rb3;
    private Button btnNext;

    int totalQuestions;
    int qCounter = 0;
    int score;

    ColorStateList dfRbColor;
    boolean answered;


    private QuestionModel currentQuestion;

    private List<QuestionModel> questionsList;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionsList = new ArrayList<>();

        tvQuestion = findViewById(R.id.textQuestion);
        tvScore = findViewById(R.id.textScore);
        tvQuestionNo = findViewById(R.id.textQuestionNo);

        radioGroup = findViewById(R.id.radioGroup);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        btnNext = findViewById(R.id.btnNext);

        dfRbColor = rb1.getTextColors();

        addQuestions();
        totalQuestions = questionsList.size();
        showNextQuestion();

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answered == false) {
                    if (rb1.isChecked() || rb2.isChecked() || rb3.isChecked()) {
                        checkAnswer();
                    } else {
                        Toast.makeText(QuizActivity.this, "Please Select an Option", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    showNextQuestion();
                }
            }
        });

    }

    private void checkAnswer() {
        answered = true;
        RadioButton rbSelected = findViewById(radioGroup.getCheckedRadioButtonId());
        int answerNo = radioGroup.indexOfChild(rbSelected) + 1;
        if (answerNo == currentQuestion.getCorrectAnsNo()) {
            score++;
            tvScore.setText("Score: " + score);
        }
        rb1.setTextColor(Color.RED);
        rb2.setTextColor(Color.RED);
        rb3.setTextColor(Color.RED);
        switch (currentQuestion.getCorrectAnsNo()) {
            case 1:
                rb1.setTextColor(Color.GREEN);
                break;
            case 2:
                rb2.setTextColor(Color.GREEN);
                break;
            case 3:
                rb3.setTextColor(Color.GREEN);
                break;
        }
        if (qCounter < totalQuestions) {
            btnNext.setText("Next");
        } else {
            btnNext.setText("Finish");
        }

    }

    private void showNextQuestion() {

        radioGroup.clearCheck();
        rb1.setTextColor(dfRbColor);
        rb2.setTextColor(dfRbColor);
        rb3.setTextColor(dfRbColor);


        if (qCounter < totalQuestions) {
            currentQuestion = questionsList.get(qCounter);
            tvQuestion.setText(currentQuestion.getQuestion());
            rb1.setText(currentQuestion.getOption1());
            rb2.setText(currentQuestion.getOption2());
            rb3.setText(currentQuestion.getOption3());

            qCounter++;
            btnNext.setText("Submit");
            tvQuestionNo.setText("Question: " + qCounter + "/" + totalQuestions);
            answered = false;

        } else {
            finish();
        }
    }

    private void addQuestions() {
        questionsList.add(new QuestionModel("When The War in Europe start?", "1939", "1937", "1932", 1));
        questionsList.add(new QuestionModel("Which event started The War in Europe", "Japan invaded Manchuria.", "Nazi Germany invaded Poland", "Fascist Italy invaded and captured Albania.", 2));
        questionsList.add(new QuestionModel("What war tactic did the Nazis use?", "Blitzkreig", "Turan", "Skirmish", 1));
        questionsList.add(new QuestionModel("Which 2 countries declared war against Germany first?", "Italy and Albania", "Netherlands and Britain", "Britain and France", 1));
        questionsList.add(new QuestionModel("Which of these was key to U.S. success at the Battle of Midway?", "Having better-trained pilots than the Japanese", "Having better aircraft", "Having cracked the main Japanese naval communications code", 3));
        questionsList.add(new QuestionModel("Japan launched an attack on the U.S. mainland by using which curious method?", "Amphibious tanks", "Helium balloons", "Scuba divers", 2));
        questionsList.add(new QuestionModel("The German military operation code-named Walküre (“Valkyrie”) hoped to assassinate which leader?", "Winston Churchill", "Adolf Hitler", "Franklin Roosevelt", 2));
        questionsList.add(new QuestionModel("Which technology helped the U.K. defeat Germany’s months long air offensive against it in the Battle of Britain?", "Radar", "Stealth airplanes", "Atomic energy", 1));
        questionsList.add(new QuestionModel("Which city was the site of a 900-day siege during World War II?", "Leningrad", "Berlin", "London", 1));
        questionsList.add(new QuestionModel("“Little Boy” and “Fat Man” were nicknames for what?", "Italy and Germany", "Stalin and Churchill", "Atomic bombs", 3));
    }
}