package com.example.a20190305006;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class QuizActivity2 extends AppCompatActivity {

    private TextView tvQuestion, tvScore, tvQuestionNo;
    private RadioGroup radioGroup;
    private RadioButton rb1, rb2, rb3;
    private Button btnNext;

    int totalQuestions;
    int qCounter = 0;
    int score;

    ColorStateList dfRbColor;
    boolean answered;


    private QuestionModel currentQuestion;

    private List<QuestionModel> questionsList;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        questionsList = new ArrayList<>();

        tvQuestion = findViewById(R.id.textQuestion);
        tvScore = findViewById(R.id.textScore);
        tvQuestionNo = findViewById(R.id.textQuestionNo);

        radioGroup = findViewById(R.id.radioGroup);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        btnNext = findViewById(R.id.btnNext);

        dfRbColor = rb1.getTextColors();

        addQuestions();
        totalQuestions = questionsList.size();
        showNextQuestion();

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (answered == false) {
                    if (rb1.isChecked() || rb2.isChecked() || rb3.isChecked()) {
                        checkAnswer();
                    } else {
                        Toast.makeText(QuizActivity2.this, "Please Select an Option", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    showNextQuestion();
                }
            }
        });

    }

    private void checkAnswer() {
        answered = true;
        RadioButton rbSelected = findViewById(radioGroup.getCheckedRadioButtonId());
        int answerNo = radioGroup.indexOfChild(rbSelected) + 1;
        if (answerNo == currentQuestion.getCorrectAnsNo()) {
            score++;
            tvScore.setText("Score: " + score);
        }
        rb1.setTextColor(Color.RED);
        rb2.setTextColor(Color.RED);
        rb3.setTextColor(Color.RED);
        switch (currentQuestion.getCorrectAnsNo()) {
            case 1:
                rb1.setTextColor(Color.GREEN);
                break;
            case 2:
                rb2.setTextColor(Color.GREEN);
                break;
            case 3:
                rb3.setTextColor(Color.GREEN);
                break;
        }
        if (qCounter < totalQuestions) {
            btnNext.setText("Next");
        } else {
            btnNext.setText("Finish");
        }

    }

    private void showNextQuestion() {

        radioGroup.clearCheck();
        rb1.setTextColor(dfRbColor);
        rb2.setTextColor(dfRbColor);
        rb3.setTextColor(dfRbColor);


        if (qCounter < totalQuestions) {
            currentQuestion = questionsList.get(qCounter);
            tvQuestion.setText(currentQuestion.getQuestion());
            rb1.setText(currentQuestion.getOption1());
            rb2.setText(currentQuestion.getOption2());
            rb3.setText(currentQuestion.getOption3());

            qCounter++;
            btnNext.setText("Submit");
            tvQuestionNo.setText("Question: " + qCounter + "/" + totalQuestions);
            answered = false;

        } else {
            finish();
        }
    }

    private void addQuestions() {
        questionsList.add(new QuestionModel("Which was an association between Great Britain, France, and Russia?", "Triple Entente", "Central Powers", "Triple Alliance", 1));
        questionsList.add(new QuestionModel("How were aircraft primarily used at the beginning of World War I?", "transporting paratroopers", "locating targets for artillery", "making supply drops", 2));
        questionsList.add(new QuestionModel("Which of these was not a result of Germany’s surrender?", "the execution of Kaiser Wilhelm II", "giving land to France", "restrictions on the German army’s size", 1));
        questionsList.add(new QuestionModel("Which animals were frequently used to carry messages during World War I?", "Cats", "Squirrels", "Pigeons", 3));
        questionsList.add(new QuestionModel("Who was president of the United States during World War I?", "William Howard Taft", "Franklin D. Roosevelt", "Woodrow Wilson", 3));
        questionsList.add(new QuestionModel("Which country made the first declaration of war?", "Serbia", "Austria-Hungary", "Russia", 2));
        questionsList.add(new QuestionModel("In what city was Archduke Franz Ferdinand assassinated?", "Belgrade", "Sarajevo", "Vienna", 2));
        questionsList.add(new QuestionModel("At the beginning of World War I, Bosnia-Herzegovina was part of", "Austria-Hungary", "Yugoslavia", "Croatia", 1));
        questionsList.add(new QuestionModel("The Battle of the Falkland Islands resulted in", "Victory for Britain", "Victory for Germany", "Victory for Turkey", 1));
        questionsList.add(new QuestionModel("Which country joined the war on the side of the Allied Powers in 1916?", "Greece", "Bulgaria", "Romania", 3));
    }
}