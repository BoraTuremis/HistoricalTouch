package com.example.a20190305006;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.os.Bundle;
import android.widget.MediaController;
import android.widget.VideoView;

public class VideoViewHere2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);setContentView(R.layout.activity_video_view_here2);

        VideoView videoView2 = (VideoView) findViewById(R.id.videoView2);
        videoView2.setVideoURI(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.projectvideo2));

        MediaController mediaController = new MediaController(this);
        videoView2.setMediaController(mediaController);
        videoView2.start();
    }
}